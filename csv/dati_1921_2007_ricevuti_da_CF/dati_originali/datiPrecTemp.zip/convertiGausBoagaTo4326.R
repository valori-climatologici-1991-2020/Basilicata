rm(list=objects())
library("sp")
options(warn=2)
options(stringsAsFactors=FALSE)

read.csv("ana.csv",sep=";",head=TRUE)->ana
coordinates(ana)=~E_GB+N_GB
#gaus boaga ovvero Roma40. Due codici epsg: 3003 e 3004
proj4string(ana)<-CRS("+init=epsg:3004")
#Questa di seguito non funziona: i dati vanno tutti in mare
#proj4string(ana)<-CRS("+proj=tmerc +ellps=intl +lat_0=0 +lon_0=9 +k=0.999600 +x_0=1500000 +y_0=0 +units=m +towgs84=-104.1,-49.1,-9.9,0.971,-2.917,0.714,-11.68")

#trasformo in epsg:4326 ovver latlon wgs84
spTransform(ana,CRS("+init=epsg:4326"))->anaWGS84
write.table(as.data.frame(anaWGS84),file="anagraficaBasilicata.csv",sep=";",col.names=TRUE,row.names=FALSE,quote=FALSE)
